package cz.muni.fi.pa165.library.dtos;

/**
 *
 * @author MiškoHu
 */
public enum Department {

    CHILDREN, FICTION, POETRY, HISTORY, RELIGION, MAGAZINES,
    TRAVEL, SPORT, ECONOMY, DICTIONARIES, SCIENCE, COOKING
}
