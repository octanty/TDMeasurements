package cz.muni.fi.pa165.pujcovnastroju.dto;

public class UnsupportedTypeException extends IllegalArgumentException {

	private static final long serialVersionUID = 1679600457692933026L;

	public UnsupportedTypeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UnsupportedTypeException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public UnsupportedTypeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public UnsupportedTypeException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
}
