package cz.mun.fi.pa165.pujcovnastrojuapi;

import junit.framework.TestCase;

import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class AppTest extends TestCase {
	
	public void testSample() {
		//TODO delete
		assertTrue(true);
	}

}
