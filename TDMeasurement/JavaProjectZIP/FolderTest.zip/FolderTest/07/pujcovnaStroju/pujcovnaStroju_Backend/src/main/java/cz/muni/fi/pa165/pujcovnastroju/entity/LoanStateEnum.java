package cz.muni.fi.pa165.pujcovnastroju.entity;

/**
 * 
 * @author Ondřej Güttner
 */
public enum LoanStateEnum {
	BOOKED, LOANED, RETURNED;
}