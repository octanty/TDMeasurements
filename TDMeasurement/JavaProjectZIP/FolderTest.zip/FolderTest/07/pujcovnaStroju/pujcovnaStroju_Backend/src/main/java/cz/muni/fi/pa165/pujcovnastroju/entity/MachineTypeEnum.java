package cz.muni.fi.pa165.pujcovnastroju.entity;

/**
 * Types of available machines
 * 
 * @author Michal Merta
 * 
 */
public enum MachineTypeEnum {
	DRILL, BULDOZER, CRANE, CAN_OPENER;
}
