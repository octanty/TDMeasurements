package cz.muni.fi.pa165.pujcovnastroju.entity;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import cz.muni.fi.pa165.pujcovnastroju.dao.SystemUserDAO;
import cz.muni.fi.pa165.pujcovnastroju.dao.SystemUserDAOImpl;

public class App {
	public static void main(String[] args) {
		
	}
}
