Booking manager REST client
=============

REST Client for Booking Manager Application

Run with: **mvn exec:java**
