Booking manager Web module
=============

Web Module for Booking Manager Application

Run with: **mvn tomcat:run**