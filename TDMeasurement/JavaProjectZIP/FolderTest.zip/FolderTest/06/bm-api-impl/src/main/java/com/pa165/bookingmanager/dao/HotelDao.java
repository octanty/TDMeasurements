package com.pa165.bookingmanager.dao;

import com.pa165.bookingmanager.entity.HotelEntity;

/**
 * @author Jakub Polak
 */
public interface HotelDao extends GenericDao<HotelEntity, Long>
{

}
