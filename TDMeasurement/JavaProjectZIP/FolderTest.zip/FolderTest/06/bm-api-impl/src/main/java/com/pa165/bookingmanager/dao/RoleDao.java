package com.pa165.bookingmanager.dao;

import com.pa165.bookingmanager.entity.RoleEntity;

/**
 * @author Jakub Polak
 */
public interface RoleDao extends GenericDao<RoleEntity, Long>
{

}
